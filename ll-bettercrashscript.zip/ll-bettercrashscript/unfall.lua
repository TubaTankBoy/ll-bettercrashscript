ESX = exports["es_extended"]:getSharedObject()

local unconscious = false
local lastCrashTime = 0
local deathChance = 25  -- Chance, sofort zu sterben
local smokeChance = 50  -- Chance, dass das Fahrzeug raucht
local crashCooldown = 5000 -- 5 Sekunden Cooldown für Crash-Erkennung

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(100) -- CPU-Last reduzieren
        local playerPed = PlayerPedId()
        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            if GetEntitySpeed(vehicle) * 3.6 > 90 then -- Ab-Geschwindigkeit > 90 km/h
                if HasEntityCollidedWithAnything(vehicle) and GetGameTimer() - lastCrashTime > crashCooldown then
                    lastCrashTime = GetGameTimer()
                    local crashChance = math.random(1, 100)
                    
                    if crashChance <= deathChance then
                        TriggerEvent('esx_unfall:playerDied', vehicle) -- Fahrzeug brennt garantiert und explodiert
                    else
                        TriggerEvent('esx_unfall:playerUnconscious', vehicle)
                    end
                end
            end
        end
    end
end)

RegisterNetEvent('esx_unfall:playerUnconscious')
AddEventHandler('esx_unfall:playerUnconscious', function(vehicle)
    local playerPed = PlayerPedId()
    unconscious = true
    SetEntityHealth(playerPed, 100)
    SetPedToRagdoll(playerPed, 5000, 5000, 0, false, false, false)
    ESX.ShowNotification('Ein Unfall... Knappes ding')
    TriggerServerEvent('esx_unfall:sendAmbulanceBlip', GetEntityCoords(playerPed))

    -- Blackscreen einblenden
    StartCrashBlackout()

    -- Fahrzeug kann rauchen, aber nicht brennen
    local smokeRoll = math.random(1, 100)
    if smokeRoll <= smokeChance then
        StartVehicleSmoke(vehicle)
    end

    Citizen.Wait(20000)
    unconscious = false
end)

RegisterNetEvent('esx_unfall:playerDied')
AddEventHandler('esx_unfall:playerDied', function(vehicle)
    local playerPed = PlayerPedId()
    SetEntityHealth(playerPed, 0)
    ESX.ShowNotification('Du bist bei dem Unfall gestorben...')

    -- Blackscreen einblenden
    StartCrashBlackout()

    if DoesEntityExist(vehicle) then
        -- Fahrzeug beschädigen und unfahrbar machen
        SetVehicleEngineHealth(vehicle, -4000)
        SetVehicleBodyHealth(vehicle, 0.0)
        SetVehicleUndriveable(vehicle, true)

        -- Feuer starten
        Citizen.Wait(3000)
        if DoesEntityExist(vehicle) then
            StartEntityFire(vehicle)
        end

        -- **Reifen platzen lassen (nur bei Tod!)**
        Citizen.Wait(2000)
        if DoesEntityExist(vehicle) then
            for i = 0, 5 do
                SetVehicleTyreBurst(vehicle, i, true, 1000.0)
            end
        end

        -- Explosion nach 10 Sekunden
        Citizen.Wait(10000)
        if DoesEntityExist(vehicle) then
            AddExplosion(GetEntityCoords(vehicle), 2, 1.0, true, false, true)
        end
    end
end)

function StartVehicleSmoke(vehicle)
    if DoesEntityExist(vehicle) then
        SetVehicleEngineHealth(vehicle, 200.0) -- Motor stark beschädigen, aber nicht zerstört
        SetVehicleBodyHealth(vehicle, 500.0) -- Karosserie sichtbar beschädigen
        SetVehicleUndriveable(vehicle, false) -- Fahrzeug bleibt steuerbar, aber beschädigt
    end
end

-- Blackscreen mit sanftem Übergang
function StartCrashBlackout()
    DoScreenFadeOut(1000) -- 2 Sekunde ausblenden
    Citizen.Wait(5000) -- 5 Sekunden Blackout
    DoScreenFadeIn(1000) -- 1 Sekunde einblenden
end
