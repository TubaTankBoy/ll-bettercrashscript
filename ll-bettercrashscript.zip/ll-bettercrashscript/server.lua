ESX = exports['es_extended']:getSharedObject()

RegisterCommand('notruf', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        TriggerClientEvent('esx:showNotification', -1, '^1[NOTRUF]^0 ' .. xPlayer.getName() .. ' hat einen Notruf gesendet!')
    end
end, false)

RegisterNetEvent('esx_unfall:sendAmbulanceBlip')
AddEventHandler('esx_unfall:sendAmbulanceBlip', function(coords)
    local xPlayers = ESX.GetExtendedPlayers('job', 'ambulance')
    for _, xPlayer in pairs(xPlayers) do
        TriggerClientEvent('esx_unfall:createAmbulanceBlip', xPlayer.source, coords)
    end
end)

