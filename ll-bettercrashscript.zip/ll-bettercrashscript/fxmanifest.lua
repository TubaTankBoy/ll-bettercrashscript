fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'Lias82 | ll-scripts'
description 'Unfall-Skript für ESX Legacy'
version '1.0.0'

client_script 'unfall.lua'
server_script 'server.lua'
