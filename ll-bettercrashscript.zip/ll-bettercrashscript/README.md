waschanlage.lua = Config.lua


### Beschreibung des Skripts:
Dieses Skript fügt funktionierende Waschanlagen in FiveM hinzu. 
Spieler können ihre Fahrzeuge an bestimmten Standorten gegen eine Gebühr reinigen lassen.

### Funktionen:
✅ Drei voreingestellte Waschanlagen-Standorte (anpassbar)
✅ Automatische Reinigung von Fahrzeugen
✅ Blips auf der Karte zur besseren Sichtbarkeit
✅ Zahlungssystem kann einfach integriert werden

### Installation:
1. Die Dateien in den Ordner "ll-waschanlagen" im "resources"-Verzeichnis hochladen.
2. In der "server.cfg" `ensure waschanlage` hinzufügen.
3. Server neustarten oder `refresh` + `start ll-waschanlagen` in die Konsole eingeben.

### Nutzung:
- Fahre zu einer der Waschanlagen (markiert auf der Karte).
- Drücke E um dein Fahrzeug zu waschen.
- Nach 5 Sekunden ist dein Fahrzeug sauber!


